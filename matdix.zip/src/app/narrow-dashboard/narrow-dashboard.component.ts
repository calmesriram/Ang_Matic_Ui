import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-narrow-dashboard',
  templateUrl: './narrow-dashboard.component.html',
  styleUrls: ['./narrow-dashboard.component.css']
})
export class NarrowDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
